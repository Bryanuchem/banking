import { Search } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

import {
  getAdminAuditLogs,
} from "@/api/admin";
import ExportCsvButton from "@/components/common/ExportCsvButton";
import SecurityHeader from "@/components/security/SecurityHeader";
import StatusBadge from "@/components/common/StatusBadge";
import type { AdminAuditLogItemV2 } from "@/types/admin";

export default function AdminAuditLogsPage() {
  const [q, setQ] = useState("");
  const [action, setAction] = useState("");
  const [entityType, setEntityType] = useState("");
  const [selected, setSelected] =
    useState<AdminAuditLogItemV2 | null>(null);

  const params = {
    q: q || undefined,
    action: action || undefined,
    entity_type: entityType || undefined,
    limit: 100,
    offset: 0,
  };

  const query = useQuery({
    queryKey: ["admin", "audit-logs", q, action, entityType],
    queryFn: () => getAdminAuditLogs(params),
  });

  return (
    <div className="space-y-5">
      <SecurityHeader
        title="Audit Logs"
        description="Track and review system activities."
        action={
          <ExportCsvButton
            resource="audit-logs"
            params={{
              q: q || undefined,
              action: action || undefined,
              entity_type: entityType || undefined,
            }}
          />
        }
      />

      <div
        className="grid gap-3 rounded-xl border p-3 md:grid-cols-[1fr_180px_180px]"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        <label className="relative">
          <Search
            size={15}
            className="absolute left-3 top-1/2 -translate-y-1/2"
            style={{ color: "var(--muted)" }}
          />
          <input
            value={q}
            placeholder="Search logs..."
            className="h-10 w-full rounded-lg border bg-transparent pl-9 pr-3 text-sm outline-none"
            style={{ borderColor: "var(--border)", color: "var(--text)" }}
            onChange={(e) => setQ(e.target.value)}
          />
        </label>
        <input
          value={action}
          placeholder="Action contains..."
          className="h-10 rounded-lg border bg-transparent px-3 text-sm outline-none"
          style={{ borderColor: "var(--border)", color: "var(--text)" }}
          onChange={(e) => setAction(e.target.value)}
        />
        <input
          value={entityType}
          placeholder="Entity type..."
          className="h-10 rounded-lg border bg-transparent px-3 text-sm outline-none"
          style={{ borderColor: "var(--border)", color: "var(--text)" }}
          onChange={(e) => setEntityType(e.target.value)}
        />
      </div>

      <div
        className="overflow-hidden rounded-[var(--radius-card)] border"
        style={{ background: "var(--surface)", borderColor: "var(--border)" }}
      >
        <div className="overflow-x-auto">
          <table className="min-w-[900px] w-full text-left text-sm">
            <thead style={{ background: "var(--surface-alt)", color: "var(--muted)" }}>
              <tr>
                {["Time", "Actor", "Action", "Entity", "Summary"].map((label) => (
                  <th key={label} className="px-4 py-3 text-xs font-semibold">{label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {query.data?.items.map((item) => (
                <tr
                  key={item.id}
                  className="cursor-pointer border-t"
                  style={{ borderColor: "var(--border)" }}
                  onClick={() => setSelected(item)}
                >
                  <td className="px-4 py-3 text-xs" style={{ color: "var(--muted)" }}>
                    {new Date(item.created_at).toLocaleString()}
                  </td>
                  <td className="px-4 py-3">
                    <p className="font-medium" style={{ color: "var(--text)" }}>
                      {item.actor_name ?? "System"}
                    </p>
                    <p className="text-xs" style={{ color: "var(--muted)" }}>
                      {item.actor_email ?? "system"}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge label={item.action} tone={tone(item.action)} />
                  </td>
                  <td className="px-4 py-3 text-xs" style={{ color: "var(--muted)" }}>
                    {item.entity_type ?? "—"}
                  </td>
                  <td className="max-w-[360px] truncate px-4 py-3 text-xs" style={{ color: "var(--muted)" }}>
                    {summary(item)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="border-t px-4 py-3 text-xs" style={{ borderColor: "var(--border)", color: "var(--muted)" }}>
          {query.data ? `${query.data.total} audit event(s)` : "Loading..."}
        </div>
      </div>

      {selected ? (
        <div className="fixed inset-0 z-[100] bg-black/50" onClick={() => setSelected(null)}>
          <aside
            className="absolute inset-y-0 right-0 w-full max-w-xl overflow-y-auto border-l p-6 shadow-2xl"
            style={{ background: "var(--surface)", borderColor: "var(--border)" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold" style={{ color: "var(--text)" }}>
                Audit detail
              </h2>
              <button onClick={() => setSelected(null)} style={{ color: "var(--muted)" }}>×</button>
            </div>
            <dl className="mt-5 grid gap-4 text-sm">
              <Detail label="Audit ID" value={selected.id} />
              <Detail label="Actor" value={selected.actor_email ?? "System"} />
              <Detail label="Action" value={selected.action} />
              <Detail label="Entity" value={`${selected.entity_type ?? "—"} / ${selected.entity_id ?? "—"}`} />
              <Detail label="Timestamp" value={new Date(selected.created_at).toLocaleString()} />
              <Detail label="IP address" value={selected.ip_address ?? "—"} />
              <Detail label="User agent" value={selected.user_agent ?? "—"} />
            </dl>
            <h3 className="mt-6 text-sm font-semibold" style={{ color: "var(--text)" }}>
              Details
            </h3>
            <pre
              className="mt-2 overflow-x-auto rounded-xl border p-4 text-xs leading-5"
              style={{
                background: "var(--surface-alt)",
                borderColor: "var(--border)",
                color: "var(--text)",
              }}
            >
              {JSON.stringify(selected.details ?? {}, null, 2)}
            </pre>
          </aside>
        </div>
      ) : null}
    </div>
  );
}

function tone(action: string): "success" | "warning" | "danger" {
  const value = action.toLowerCase();
  if (value.includes("disabled") || value.includes("failed") || value.includes("revoked")) {
    return "danger";
  }
  if (value.includes("created") || value.includes("enabled") || value.includes("completed")) {
    return "success";
  }
  return "warning";
}

function summary(item: AdminAuditLogItemV2) {
  const details = item.details ?? {};
  const values = Object.entries(details)
    .filter(([key]) => !key.toLowerCase().includes("secret"))
    .slice(0, 3)
    .map(([key, value]) => `${key}: ${String(value)}`);
  return values.join(" • ") || item.action;
}

function Detail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs font-medium" style={{ color: "var(--muted)" }}>{label}</dt>
      <dd className="mt-1 break-words" style={{ color: "var(--text)" }}>{value}</dd>
    </div>
  );
}
