import { authorizeAdminStepUp } from "@/api/admin";

export async function requestAdminStepUp(
  scope: string,
) {
  const code = window.prompt(
    "Enter your two-factor authentication code to continue. If 2FA is not enabled on your administrator account, leave this blank and continue.",
    "",
  );

  if (code === null) {
    throw new Error("ACTION_CANCELLED");
  }

  if (!code.trim()) {
    return undefined;
  }

  const result = await authorizeAdminStepUp(
    scope,
    code.trim(),
  );
  return result.authorization_token;
}
