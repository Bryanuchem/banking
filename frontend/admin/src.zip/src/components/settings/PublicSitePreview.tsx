import {
  ArrowRight,
  Headphones,
  ShieldCheck,
  Zap,
} from "lucide-react";
import {
  FaDiscord,
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
  FaTelegram,
  FaTiktok,
  FaWhatsapp,
  FaXTwitter,
  FaYoutube,
} from "react-icons/fa6";

import {
  type Draft,
  valueString,
} from "@/pages/Settings/settings";

function initials(name: string) {
  return (
    name
      .split(/\s+/)
      .filter(Boolean)
      .map((part) => part[0])
      .join("")
      .slice(0, 2)
      .toUpperCase() || "B"
  );
}

export default function PublicSitePreview({
  draft,
  mode,
}: {
  draft: Draft;
  mode: "branding" | "landing" | "support";
}) {
  const brand =
    valueString(draft, "brand_name") || "Banking";
  const primary =
    valueString(
      draft,
      "brand_light_primary_color",
    ) || "#2563EB";
  const accent =
    valueString(
      draft,
      "brand_light_accent_color",
    ) || "#5B7FFF";

  if (mode === "support") {
    const channels = [
      [
        "Email",
        valueString(draft, "support_email"),
        null,
      ],
      [
        "Phone",
        valueString(draft, "support_phone"),
        null,
      ],
      [
        "WhatsApp",
        valueString(draft, "support_whatsapp_url"),
        FaWhatsapp,
      ],
      [
        "Telegram",
        valueString(draft, "support_telegram_url"),
        FaTelegram,
      ],
      [
        "Hours",
        valueString(draft, "support_hours"),
        null,
      ],
    ].filter(([, value]) => value);

    const socials = [
      [FaFacebookF, "social_facebook_url", "Facebook"],
      [FaInstagram, "social_instagram_url", "Instagram"],
      [FaXTwitter, "social_x_url", "X"],
      [FaLinkedinIn, "social_linkedin_url", "LinkedIn"],
      [FaYoutube, "social_youtube_url", "YouTube"],
      [FaTiktok, "social_tiktok_url", "TikTok"],
      [FaDiscord, "social_discord_url", "Discord"],
    ].filter(([, key]) => valueString(draft, String(key)));

    return (
      <PreviewFrame title="Live preview">
        <div className="rounded-xl bg-white p-5 text-slate-900">
          <Headphones size={28} className="mb-4" />
          <h3 className="text-xl font-bold">Need help?</h3>
          <p className="mt-1 text-sm text-slate-500">
            Get in touch with our support team.
          </p>

          <div className="mt-5 space-y-2 text-sm">
            {channels.length ? (
              channels.map(([label, value, Icon]) => (
                <div
                  key={String(label)}
                  className="flex items-center gap-2"
                >
                  {Icon ? (
                    <Icon
                      size={15}
                      aria-hidden="true"
                    />
                  ) : null}
                  <span>
                    <span className="font-semibold">
                      {String(label)}:
                    </span>{" "}
                    {String(value)}
                  </span>
                </div>
              ))
            ) : (
              <p className="text-slate-400">
                Add support channels to preview them.
              </p>
            )}
          </div>

          <div className="mt-5 flex flex-wrap gap-2">
            {socials.map(([Icon, key, label]) => (
              <a
                key={String(key)}
                href={valueString(draft, String(key))}
                target="_blank"
                rel="noreferrer"
                aria-label={String(label)}
                title={String(label)}
                className="grid size-9 place-items-center rounded-lg border transition hover:bg-slate-50"
              >
                <Icon size={16} aria-hidden="true" />
              </a>
            ))}
          </div>
        </div>
      </PreviewFrame>
    );
  }

  const title =
    mode === "branding"
      ? valueString(draft, "brand_tagline") ||
        "Private banking, clearly managed."
      : valueString(draft, "landing_title") ||
        "Your money, clearly managed.";

  const description =
    valueString(draft, "landing_description") ||
    "A calm, secure place to manage your banking.";

  const features = [1, 2, 3].map((number) => ({
    title:
      valueString(
        draft,
        `landing_feature_${number}_title`,
      ) || `Feature ${number}`,
    description:
      valueString(
        draft,
        `landing_feature_${number}_description`,
      ) || "Feature description",
  }));

  return (
    <PreviewFrame title="Live preview">
      <div
        className="overflow-hidden rounded-xl border bg-white text-slate-950"
        style={{
          borderColor: "#dbe2ea",
        }}
      >
        <div className="flex items-center justify-between border-b px-4 py-3">
          <div className="flex items-center gap-2">
            <span
              className="grid size-8 place-items-center rounded-lg text-xs font-bold text-white"
              style={{ background: primary }}
            >
              {initials(brand)}
            </span>
            <span className="text-sm font-bold">
              {brand}
            </span>
          </div>
          <span className="text-lg">☰</span>
        </div>

        <div
          className="p-5 text-white"
          style={{
            background:
              `linear-gradient(135deg, ${primary}, ${accent})`,
          }}
        >
          {mode === "landing" ? (
            <p className="text-[10px] font-bold uppercase tracking-[0.16em] opacity-80">
              {valueString(
                draft,
                "landing_eyebrow",
              )}
            </p>
          ) : null}

          <h3 className="mt-3 max-w-[280px] text-3xl font-bold leading-[1.05]">
            {title}
          </h3>

          {mode === "landing" ? (
            <p className="mt-3 max-w-[320px] text-sm leading-6 opacity-85">
              {description}
            </p>
          ) : null}

          <div className="mt-5 flex flex-wrap gap-2">
            <span className="rounded-lg bg-white px-3 py-2 text-xs font-bold text-slate-900">
              {valueString(
                draft,
                "landing_primary_cta_label",
              ) || "Create your account"}
            </span>
            <span className="rounded-lg border border-white/50 px-3 py-2 text-xs font-bold">
              {valueString(
                draft,
                "landing_secondary_cta_label",
              ) || "Sign in"}
            </span>
          </div>
        </div>

        {mode === "landing" ? (
          <div className="grid gap-2 p-4 sm:grid-cols-3">
            {features.map((feature, index) => {
              const Icon = [
                ShieldCheck,
                Zap,
                ArrowRight,
              ][index];
              return (
                <div
                  key={feature.title}
                  className="rounded-lg border p-3"
                >
                  <Icon size={17} />
                  <p className="mt-2 text-xs font-bold">
                    {feature.title}
                  </p>
                  <p className="mt-1 text-[10px] leading-4 text-slate-500">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        ) : null}
      </div>
    </PreviewFrame>
  );
}

function PreviewFrame({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <aside
      className="rounded-[var(--radius-card)] border p-4"
      style={{
        background: "var(--surface)",
        borderColor: "var(--border)",
      }}
    >
      <div className="mb-3">
        <h3
          className="font-semibold"
          style={{ color: "var(--text)" }}
        >
          {title}
        </h3>
        <p
          className="mt-1 text-xs"
          style={{ color: "var(--muted)" }}
        >
          How this appears on the public site
        </p>
      </div>
      {children}
    </aside>
  );
}
