from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.constants.setting_key import SettingKeys
from app.services.setting_service import SettingService


class BrandThemeTokens(BaseModel):
    primary: str
    secondary: str
    accent: str
    background: str
    surface: str
    surface_alt: str
    text: str
    muted: str
    border: str
    success: str
    warning: str
    danger: str


class PublicBranding(BaseModel):
    brand_name: str
    brand_short_name: str
    support_email: str | None
    support_phone: str | None
    logo_url: str | None
    favicon_url: str | None
    primary_currency: str
    brand_theme_light: BrandThemeTokens
    brand_theme_dark: BrandThemeTokens


def _theme(
    db: Session,
    *,
    primary: str,
    secondary: str,
    accent: str,
    background: str,
    surface: str,
    surface_alt: str,
    text: str,
    muted: str,
    border: str,
    success: str,
    warning: str,
    danger: str,
) -> BrandThemeTokens:
    return BrandThemeTokens(
        primary=SettingService.get_string(db, primary),
        secondary=SettingService.get_string(db, secondary),
        accent=SettingService.get_string(db, accent),
        background=SettingService.get_string(db, background),
        surface=SettingService.get_string(db, surface),
        surface_alt=SettingService.get_string(db, surface_alt),
        text=SettingService.get_string(db, text),
        muted=SettingService.get_string(db, muted),
        border=SettingService.get_string(db, border),
        success=SettingService.get_string(db, success),
        warning=SettingService.get_string(db, warning),
        danger=SettingService.get_string(db, danger),
    )


def get_public_branding(db: Session) -> PublicBranding:
    return PublicBranding(
        brand_name=SettingService.get_string(
            db,
            SettingKeys.BRAND_NAME,
            "Banking",
        ),
        brand_short_name=SettingService.get_string(
            db,
            SettingKeys.BRAND_SHORT_NAME,
            "Banking",
        ),
        support_email=SettingService.get_string(
            db,
            SettingKeys.SUPPORT_EMAIL,
            "",
        ) or None,
        support_phone=SettingService.get_string(
            db,
            SettingKeys.SUPPORT_PHONE,
            "",
        ) or None,
        logo_url=SettingService.get_string(
            db,
            SettingKeys.LOGO_URL,
            "",
        ) or None,
        favicon_url=SettingService.get_string(
            db,
            SettingKeys.FAVICON_URL,
            "",
        ) or None,
        primary_currency=SettingService.get_string(
            db,
            SettingKeys.PRIMARY_CURRENCY,
            "USD",
        ),
        brand_theme_light=_theme(
            db,
            primary=SettingKeys.BRAND_LIGHT_PRIMARY_COLOR,
            secondary=SettingKeys.BRAND_LIGHT_SECONDARY_COLOR,
            accent=SettingKeys.BRAND_LIGHT_ACCENT_COLOR,
            background=SettingKeys.BRAND_LIGHT_BACKGROUND_COLOR,
            surface=SettingKeys.BRAND_LIGHT_SURFACE_COLOR,
            surface_alt=SettingKeys.BRAND_LIGHT_SURFACE_ALT_COLOR,
            text=SettingKeys.BRAND_LIGHT_TEXT_COLOR,
            muted=SettingKeys.BRAND_LIGHT_MUTED_COLOR,
            border=SettingKeys.BRAND_LIGHT_BORDER_COLOR,
            success=SettingKeys.BRAND_LIGHT_SUCCESS_COLOR,
            warning=SettingKeys.BRAND_LIGHT_WARNING_COLOR,
            danger=SettingKeys.BRAND_LIGHT_DANGER_COLOR,
        ),
        brand_theme_dark=_theme(
            db,
            primary=SettingKeys.BRAND_DARK_PRIMARY_COLOR,
            secondary=SettingKeys.BRAND_DARK_SECONDARY_COLOR,
            accent=SettingKeys.BRAND_DARK_ACCENT_COLOR,
            background=SettingKeys.BRAND_DARK_BACKGROUND_COLOR,
            surface=SettingKeys.BRAND_DARK_SURFACE_COLOR,
            surface_alt=SettingKeys.BRAND_DARK_SURFACE_ALT_COLOR,
            text=SettingKeys.BRAND_DARK_TEXT_COLOR,
            muted=SettingKeys.BRAND_DARK_MUTED_COLOR,
            border=SettingKeys.BRAND_DARK_BORDER_COLOR,
            success=SettingKeys.BRAND_DARK_SUCCESS_COLOR,
            warning=SettingKeys.BRAND_DARK_WARNING_COLOR,
            danger=SettingKeys.BRAND_DARK_DANGER_COLOR,
        ),
    )
